<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OliShop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php
$total_items = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total_items += $item['quantity'];
    }
}
?>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">OliShop</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="#Acceuil">Accueil</a></li>
          <li class="nav-item"><a class="nav-link" href="#boutique">Boutique</a></li>
          <li class="nav-item"><a class="nav-link" href="#propos">À propos</a></li>
          <li class="nav-item"><a class="nav-link" href="#actualite">Actualité</a></li>
          <li class="nav-item"><a class="nav-link" href="#flag">Contact/Flag</a></li>
          <li class="nav-item">
    <a class="nav-link" href="cart.php">
        Panier <span class="badge badge-pill badge-success"><?= $total_items ?></span>
    </a>
</li>

        </ul>
      </div>
    </div>
  </nav>

  <!-- Spacer for fixed navbar -->
  <div style="margin-top: 80px;"></div>

  <!-- acceuil Section -->
  <div class="hero-section" id="Accueil">
    <div class="container">
     
      <h1>OliShop</h1>
    </div>
  </div>

 <!-- Categories Section -->
<section class="categories py-5">
  <div class="container">
    <h2 class="text-center mb-4">CATÉGORIES</h2>
    <div class="row g-4">
      <div class="col-md-2">
        <img class="rotatable-image" src="image/lit3.png" alt="Category" onclick="rotateImage(this)">
        <h6>Lit en sois</h6>
        <button class="btn btn-primary mt-2" onclick="window.location.href='html/gallerylit.html'">Voir plus</button>
      </div>
      <div class="col-md-2" id="boutique">
        <img class="rotatable-image" src="image/chaise.png" alt="Category" onclick="rotateImage(this)">
        <h6>Chaise en platique</h6>
        <button class="btn btn-primary mt-2" onclick="window.location.href='html/gallerychaise.html'">Voir plus</button>
      </div>
      <div class="col-md-2">
        <img class="rotatable-image" src="image/lit6.png" alt="Category" onclick="rotateImage(this)">
        <h6>Lit en laine</h6>
        <button class="btn btn-primary mt-2" onclick="window.location.href='html/gallerylit.html'">Voir plus</button>
      </div>
      <div class="col-md-2">
        <img class="rotatable-image" src="image/lit3.png" alt="Category" onclick="rotateImage(this)">
        <h6>Lit en paille</h6>
        <button class="btn btn-primary mt-2" onclick="window.location.href='html/gallerylit.html'">Voir plus</button>
      </div>
      <div class="col-md-2">
        <img class="rotatable-image" src="image/lit5.png" alt="Category" onclick="rotateImage(this)">
        <h6>Chaise en paille</h6>
        <button class="btn btn-primary mt-2" onclick="window.location.href='html/gallerychaise.html'">Voir plus</button>
      </div>
      <div class="col-md-2">
        <img class="rotatable-image" src="image/lit4.png" alt="Category" onclick="rotateImage(this)">
        <h6>Lit en peau</h6>
        <button class="btn btn-primary mt-2" onclick="window.location.href='html/gallerylit.html'">Voir plus</button>
      </div>
    </div>
  </div>
</section>


 
<script>
function rotateImage(image) {
  image.classList.add('rotated');
  setTimeout(() => {
    image.classList.remove('rotated');
  }, 1000);
}
</script>


  <!-- Inspiration Section -->
  <section class="py-5">
    <div class="container">
      <h2 class="text-center mb-4">Inspirez-vous de nos décorations</h2>
      <div class="row justify-content-center g-4">
       
        <div class="col-md-6">
          <div class="image-wrapper">
            <img src="image/lit.png" alt="Inspiration" class="img-fluid" style="margin: 10; width: 700px; height: 400px;">
          </div>
        </div>
  
        
        <div class="col-md-6">
          <div class="image-wrapper mb-4">
            <img src="image/lit1.png" alt="Inspiration 1" class="img-fluid" style="margin: 10; width: 700px; height: 180px;">
          </div>
          <div class="image-wrapper">
            <img src="image/lit2.png" alt="Inspiration 2" class="img-fluid" style="margin: 10; width: 700px; height: 180px;">
          </div>
        </div>
      </div>
    </div>
  </section>
     <!-- Nos meilleur propoduit -->
  <section class="py-5 bg-light">
    <div class="container">
      <h2 class="text-center mb-4">Meilleurs Produits</h2>
      <div class="row g-4">
     
        <div class="col-md-3">
          <div class="card product-card">
            <img src="image/lit3.png" alt="Product">
            <div class="card-body text-center">
              <h6>Lit en soie</h6>
              <p class="text-muted">PRIX 80,000 XOF</p>
              <form method="POST" action="add_to_cart.php">
                <input type="hidden" name="product_name" value="Lit en soie">
                <input type="hidden" name="price" value="80000">
                <button type="submit" class="btn btn-success">Ajouter au panier</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card product-card">
            <img src="image/lit5.png" alt="Product">
            <div class="card-body text-center">
              <h6>Chaise en plastique</h6>
              <p class="text-muted">PRIX 50,000 XOF</p>
              <form method="POST" action="add_to_cart.php">
              <input type="hidden" name="product_name" value="chaise en plastique">
              <input type="hidden" name="price" value="50000">
              <button type="submit" class="btn btn-success" >Ajouter au panier</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card product-card">
            <img src="image/lit4.png" alt="Product">
            <div class="card-body text-center">
              <h6>Lit en coton</h6>
              <p class="text-muted">PRIX 30,000 XOF</p>
              <form method="POST" action="add_to_cart.php">
              <input type="hidden" name="product_name" value="Lit en coton">
              <input type="hidden" name="price" value="30000">
              <button type="submit" class="btn btn-success" >Ajouter au panier</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card product-card">
            <img src="image/chaise.png" alt="Product">
            <div class="card-body text-center">
              <h6>Chaise en paille</h6>
              <p class="text-muted">PRIX 80,000 XOF</p>
              <form method="POST" action="add_to_cart.php">
              <input type="hidden" name="product_name" value="Chaise en paille">
              <input type="hidden" name="price" value="20000">
              <button type="submit" class="btn btn-success" >Ajouter au panier</button>
              </form>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  </section>
  <section class="py-5 bg-light">
    <div class="container">
      <h2 class="text-center mb-4">Meilleurs Produits</h2>
      <div class="row g-4">
        <div class="col-md-3">
          <div class="card product-card">
            <img src="image/lit3.png" alt="Product">
            <div class="card-body text-center">
              <h6>Lit en soie</h6>
              <p class="text-muted">PRIX 80,000 XOF</p>
              <form method="POST" action="add_to_cart.php">
                <input type="hidden" name="product_name" value="Lit en soie">
                <input type="hidden" name="price" value="80000">
                <button type="submit" class="btn btn-success">Ajouter au panier</button>
              </form>
            </div>
          </div>
        </div>
        <!-- Add similar blocks for other products -->
      </div>
    </div>
  </section>

  <!-- Modal pour Form -->
  <div class="modal fade" id="buyModal" tabindex="-1" aria-labelledby="buyModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="buyModalLabel">Acheter le produit</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="buyForm">
            <div class="mb-3">
              <label for="name" class="form-label">Nom complet</label>
              <input type="text" class="form-control" id="name" placeholder="Entrez votre nom" required>
            </div>
            <div class="mb-3">
              <label for="email" class="form-label">Email</label>
              <input type="email" class="form-control" id="email" placeholder="Entrez votre email" required>
            </div>
            <div class="mb-3">
              <label for="address" class="form-label">Adresse</label>
              <textarea class="form-control" id="address" rows="3" placeholder="Entrez votre adresse" required></textarea>
            </div>
            <button type="button" class="btn btn-primary" id="confirmPurchase">Acheter</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Confirmation Popup -->
  <script>
    document.getElementById('confirmPurchase').addEventListener('click', function () {
      alert("Merci pour votre achat ! Votre commande a été enregistrée.");
      const modal = bootstrap.Modal.getInstance(document.getElementById('buyModal'));
      modal.hide();
    });
  </script>
   <!-- a propos -->
  <section class="apropos py-5 " id="propos">
    <div class="container">
      <h2 class="text-center mb-5">À propos</h2>
      <div class="row align-items-center">
       
        <div class="col-md-6 d-flex justify-content-center">
          <img src="image/apropos.png" alt="À propos de nous" class="img-fluid about-image" style="height: 400px;">
        </div>
  
        
        <div class="col-md-6">
          <p>
            Bienvenue chez <strong>OliShop</strong>, votre boutique en ligne préférée pour des décorations uniques et inspirantes. 
            Nous nous engageons à offrir des produits de qualité qui transforment votre maison en un espace élégant et chaleureux.
          </p>
          <p>
            Notre mission est de vous inspirer à créer des intérieurs magnifiques en mettant à votre disposition des produits
            soigneusement sélectionnés. Faites de votre maison un lieu où il fait bon vivre !
          </p>
        </div>
      </div>
    </div>
  </section>
   <!-- Footer -->
    <footer class="footer-container" id="flag">
      <div class="container">
        <div class="row">
         
          <div class="col-md-3 footer-logo">
            <h4>OliShop</h4>
            <img src="image/apropos.png" alt="Logo">
          </div>
  
          
          <div class="col-md-2 footer-section">
            <h5>Reseaux sociaux</h5>
            <ul>
              <li><a href="#">Instagramme</a></li>
              <li><a href="#">Facebook</a></li>
              <li><a href="#">Twitter</a></li>
              <li><a href="#">Whatsapp</a></li>
            </ul>
          </div>
  
          
          <div class="col-md-2 footer-section">
            <h5>Produit</h5>
            <ul>
              <li><a href="#">Chaise</a></li>
              <li><a href="#">Lit</a></li>
              <li><a href="#">Fauteille</a></li>
              <li><a href="#">Canapé</a></li>
              <li><a href="#">Coussin</a></li>
            </ul>
          </div>
  
        
          <div class="col-md-2 footer-section">
            <h5>Categorie</h5>
            <ul>
              <li><a href="#">Lit</a></li>
              <li><a href="#">Chaise</a></li>
              <li><a href="#">Drap</a></li>
            </ul>
          </div>
  
          <div class="col-md-3 footer-section">
            <h5>Nous rejoindre</h5>
            <div class="footer-input-group d-flex">
              <input type="email" class="form-control" placeholder="Votre email">
              <button class="btn">
                <span>&rarr;</span>
              </button>
            </div>
          </div>
        </div>
  
       
        <div class="row footer-bottom text-center mt-4">
          <div class="col-6 text-start">
            <p>Copyright© 2024 OliShop</p>
          </div>
          <div class="col-6 text-end">
            <a href="#">Terme et conditions</a>
          </div>
        </div>
      </div>
    </footer>
  
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
```

