<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Panier</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container py-5">
        <h1 class="text-center mb-4">Mon Panier</h1>

        <?php
        if (!empty($_SESSION['cart'])) {
            $totalPrice = 0;
            echo "<table class='table table-bordered text-center'>
                    <thead class='table-light'>
                        <tr>
                            <th>Nom du produit</th>
                            <th>Prix</th>
                            <th>Quantité</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>";

            foreach ($_SESSION['cart'] as $product) {
                $product_name = $product['product_name'] ?? 'Nom non défini';
                $price = $product['price'] ?? 0;
                $quantity = $product['quantity'] ?? 1; // Par défaut à 1 si non défini
                $total = $price * $quantity;
                $totalPrice += $total;

                echo "<tr>
                        <td>{$product_name}</td>
                        <td>{$price} €</td>
                        <td>{$quantity}</td>
                        <td>{$total} €</td>
                      </tr>";
            }

            echo "</tbody>
                  </table>";

            echo "<div class='text-end mb-4'>
                    <h4>Total : <span class='text-success'>{$totalPrice} €</span></h4>
                  </div>";
            echo "<div class='text-end'>
                    <button class='btn btn-primary' data-bs-toggle='modal' data-bs-target='#orderModal'>Acheter</button>
                  </div>";
        } else {
            echo "<p class='alert alert-warning text-center'>Votre panier est vide.</p>";
        }
        ?>

        <!-- Modal de commande -->
        <div class="modal fade" id="orderModal" tabindex="-1" aria-labelledby="orderModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="orderModalLabel">Formulaire de commande</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="process_order.php">
                            <div class="mb-3">
                                <label for="name" class="form-label">Nom complet</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="address" class="form-label">Adresse</label>
                                <textarea class="form-control" id="address" name="address" rows="3" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="payment" class="form-label">Mode de paiement</label>
                                <select class="form-select" id="payment" name="payment" required>
                                    <option value="credit_card">Carte de crédit</option>
                                    <option value="paypal">PayPal</option>
                                    <option value="bank_transfer">Virement bancaire</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-success w-100">Passer la commande</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
