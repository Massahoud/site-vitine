<?php

function calculateSum(array $numbers): int {
    $sum = 0;
    foreach ($numbers as $number) {
        $sum += $number;
    }
    return $sum;
}
$numbers = [1, 2, 3, 4, 5];
echo "La somme des nombres est : " . calculateSum($numbers);


function formatDateToFrench(string $date): string {
    $dateTime = new DateTime($date);
    return $dateTime->format('d/m/Y');
}
$date = "2025-01-15";
echo "Date au format français : " . formatDateToFrench($date);


function isPalindrome(string $text): bool {
    $cleanedText = preg_replace('/[^a-z0-9]/i', '', strtolower($text));
    return $cleanedText === strrev($cleanedText);
}
$text = "A man a plan a canal Panama";
if (isPalindrome($text)) {
    echo "'$text' est un palindrome.";
} else {
    echo "'$text' n'est pas un palindrome.";
}


function generateRandomPassword(int $length = 8): string {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()';
    return substr(str_shuffle($characters), 0, $length);
}
$password = generateRandomPassword(12);
echo "Mot de passe généré : " . $password;


function sortArrayByKey(array $array, string $key): array {
    usort($array, fn($a, $b) => $a[$key] <=> $b[$key]);
    return $array;
}
$to = "example@example.com";
$subject = "Test Subject";
$message = "Ceci est un message de test.";
$headers = "From: no-reply@example.com";
if (sendEmail($to, $subject, $message, $headers)) {
    echo "Email envoyé avec succès.";
} else {
    echo "Échec de l'envoi de l'email.";
}
$array = [
    ['name' => 'Alice', 'age' => 30],
    ['name' => 'Bob', 'age' => 25],
    ['name' => 'Charlie', 'age' => 35]
];
$sortedArray = sortArrayByKey($array, 'age');
print_r($sortedArray);


function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}
if (isLoggedIn()) {
    echo "L'utilisateur est connecté.";
} else {
    echo "L'utilisateur n'est pas connecté.";
}


function formatFileSize(int $bytes): string {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $power = $bytes > 0 ? floor(log($bytes, 1024)) : 0;
    return number_format($bytes / (1024 ** $power), 2) . ' ' . $units[$power];
}
$fileSize = 1048576; // Taille en octets (1 Mo)
echo "Taille du fichier : " . formatFileSize($fileSize);


function redirect(string $url): void {
    header("Location: $url");
    exit();
}

?>