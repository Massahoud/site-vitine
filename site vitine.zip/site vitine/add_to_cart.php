<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = $_POST['product_name'];
    $price = $_POST['price'];

    // Initialiser la session du panier si elle n'existe pas
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Vérifiez si le produit existe déjà dans le panier
    $product_exists = false;
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['name'] === $product_name) {
            $item['quantity'] += 1;
            $product_exists = true;
            break;
        }
    }

    // Si le produit n'existe pas, l'ajouter comme nouvel article
    if (!$product_exists) {
        $_SESSION['cart'][] = [
            'name' => $product_name,
            'price' => $price,
            'quantity' => 1,
        ];
    }
}

header('Location: index.php'); // Retour à la page principale
exit();
?>
